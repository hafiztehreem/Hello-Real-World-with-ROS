#!/usr/bin/env python

import rospy
from flexbe_core import EventState
from flexbe_core.proxy import ProxyServiceCaller

from hrwros_gazebo.srv import SetConveyorControl, SetConveyorControlRequest


class SetConveyorPowerState(EventState):
    # Documaentation of state implementation
    '''Update the speed of the conveyor belt througha service call
    -- stop       bool          If 'true' the state instance stops the 
                                conveyor belt, ignoring the speed input key

    ># speed      float         speed for the conveyor belt
    <= succeeded                The speed was successfully updated
    <= failed                   There was a problem setting the speed
    '''
    def __init__(self,stop):
        # Declare outcomes, input_keys, and output_keys by calling the super 
        # constructor with the corresponding arguments.
    
    super(SetConveyorPowerState, self).__init__(outcomes = ['succeeded', 
                                                            'failed'], input_keys = ['speed'])
    
    # Store state parameter for later use
    self._stop = bool(stop)

    # initialize service proxy
    self._srv = ProxyServiceCaller({self._srv_topic: SetConveyorPower})

    def on_enter(self, userdata):
        self.speed = userdata.speed
        # create service request depending on activation paramet and user data
        self._srv_req = SetConveyorControlRequest()

        